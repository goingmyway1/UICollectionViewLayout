//
//  XFCollectionViewCell.m
//  UICollectionViewLayout
//
//  Created by XF on 16/8/17.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#import "XFCollectionViewCell.h"

@implementation XFCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.imageView.layer.cornerRadius = 5.0f;
    self.imageView.layer.masksToBounds = YES;
    self.backView.layer.shadowColor = [UIColor blackColor].CGColor;
    self.backView.layer.shadowOpacity = 0.7;
    self.backView.layer.shadowRadius = 5.0f;
    self.backView.layer.shadowOffset = CGSizeMake(2, 6);
    self.backView.layer.cornerRadius = 15.0f;
    self.backView.layer.masksToBounds = YES;
}

@end
