//
//  XFCollectionViewFlowLayout.h
//  UICollectionViewLayout
//
//  Created by XF on 16/8/17.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol XFCollectionViewFlowLayoutDelegate <NSObject>

-(void)collectionViewScrollToIndex:(NSInteger)index;

@end

@interface XFCollectionViewFlowLayout : UICollectionViewFlowLayout

@property (assign, nonatomic) id<XFCollectionViewFlowLayoutDelegate>delegate;

@property (assign ,nonatomic) BOOL needAlpha;

@end
