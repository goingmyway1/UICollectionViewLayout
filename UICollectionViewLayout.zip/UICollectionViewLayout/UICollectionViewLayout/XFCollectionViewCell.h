//
//  XFCollectionViewCell.h
//  UICollectionViewLayout
//
//  Created by XF on 16/8/17.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XFCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIView *backView;

@property (strong, nonatomic) IBOutlet UIImageView *imageView;
@end
