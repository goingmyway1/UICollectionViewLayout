//
//  XFItemModel.m
//  UICollectionViewLayout
//
//  Created by XF on 16/8/18.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#import "XFItemModel.h"

@implementation XFItemModel

@end
