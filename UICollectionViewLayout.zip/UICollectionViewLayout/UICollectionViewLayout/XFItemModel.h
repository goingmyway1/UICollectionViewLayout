//
//  XFItemModel.h
//  UICollectionViewLayout
//
//  Created by XF on 16/8/18.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XFItemModel : NSObject

@property (copy, nonatomic) NSString *imageName;

@property (copy, nonatomic) NSString *titleName;

@end
