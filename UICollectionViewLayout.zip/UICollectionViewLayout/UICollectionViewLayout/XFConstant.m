//
//  XFConstant.m
//  UICollectionViewLayout
//
//  Created by XF on 16/8/18.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#import "XFConstant.h"


const CGFloat XFLineSpacing = 40.f;
const CGFloat XFZoomScale = 1.45f;
const CGFloat XFMinZoomScale = XFZoomScale - 1.0f;
