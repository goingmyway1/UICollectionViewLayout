//
//  XFMainPopoutView.h
//  UICollectionViewLayout
//
//  Created by XF on 16/8/18.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XFItemModel.h"

@protocol XFMainPopoutViewDelegate <NSObject>

-(void)selectedImage:(XFItemModel *)item;

-(void)closePopView;

@end

@interface XFMainPopoutView : UIView

@property (weak, nonatomic) id<XFMainPopoutViewDelegate> delegate;

@property (strong, nonatomic) NSArray *dataSource;

- (void)showInSuperView:(UIView *)superView;

@end
