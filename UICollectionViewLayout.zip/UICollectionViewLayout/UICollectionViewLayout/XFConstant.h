//
//  XFConstant.h
//  UICollectionViewLayout
//
//  Created by XF on 16/8/18.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define RGB(r,g,b,a)    [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:a]

#define SCREEN_WIDTH [UIScreen  mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height

UIKIT_EXTERN const CGFloat XFLineSpacing; // item间距
UIKIT_EXTERN const CGFloat XFZoomScale; // 缩放比例
UIKIT_EXTERN const CGFloat XFMinZoomScale; // 最小缩放比例

