//
//  AppDelegate.h
//  UICollectionViewLayout
//
//  Created by XF on 16/8/17.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

